import fs from 'node:fs';
import vm from 'node:vm';
const context={window:{}};vm.runInNewContext(fs.readFileSync('public/i18n.js','utf8'),context);
const all=context.window.VIZ_I18N,keys=Object.keys(all.tr).sort(),markup=fs.readFileSync('public/index.html','utf8');
for(const language of ['tr','uz','en']){
 if(JSON.stringify(Object.keys(all[language]).sort())!==JSON.stringify(keys))throw Error(`Translation keys differ: ${language}`);
 for(const key of keys){const value=all[language][key];if(typeof value!=='string'||!value.trim())throw Error(`Empty: ${language}.${key}`);const placeholders=s=>[...s.matchAll(/\{([^}]+)\}/g)].map(m=>m[1]).sort().join(',');if(placeholders(value)!==placeholders(all.tr[key]))throw Error(`Placeholder mismatch: ${language}.${key}`);}
}
for(const match of markup.matchAll(/data-i18n(?:-aria)?="([^"]+)"/g))if(!keys.includes(match[1]))throw Error(`Unknown UI key: ${match[1]}`);
console.log(`Verified ${keys.length} strings in Turkish, Uzbek and English, including UI keys and dynamic placeholders.`);

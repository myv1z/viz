# VIZ

Turkish, Uzbek and English streamer website, served by a dependency-free Worker. Editable browser assets are in `public/`; `dist/server/index.js` is the generated deployment module. Public links are in `public/config.js`; credentials must never be put there.

## Pending owner information

iDonate donation URL and FACEIT integration remain pending. Premier is connected to Leetify. Kick and sponsorship email are configured. The crosshair code is stored verbatim as confirmed by the owner; no in-game import was performed. The preview is illustrative.

## Statistics

No simulated statistics are displayed. `/api/stats` queries the official Leetify public profile API for the fixed owner Steam ID. Only the Premier rating, check time, latest tracked match time and source state are returned. No other player data or credentials are returned. Polling occurs once per minute while visible, and on returning to the tab. The check time is not presented as the provider's data update time. Provider data may update after matches rather than during a match.

Expected JSON: `{ "updatedAt": "2026-11-11T10:00:00Z", "faceit": { "elo": null, "level": null, "kd": null, "winrate": null, "headshots": null }, "premier": { "rating": null } }`. Percentages are in 0–100 units; null means unavailable. A valid update timestamp is required.

FACEIT account: v1z. Steam ID: 76561199473295357. FACEIT fields remain null until their own data source is configured. Leetify requests currently work without a key; an optional LEETIFY_API_KEY can be supplied only through secret runtime environment configuration. No profile data is persistently cached. The UI backs off after rate limiting. A private or unavailable profile clears previously displayed values. Attribution uses the official unmodified Leetify badge and a View on Leetify link.

Crosshair preview is illustrative. The confirmed code can be copied; import instructions are available. Motion controls respect the operating system preference and persist the visitor's explicit reduced-motion preference when storage is available.

## Theme

General streamer and creator identity, with Kick and Discord as primary destinations. CS2 stats remain in a secondary game corner; crosshair is in an expandable panel. `studio.css` is the single active stylesheet. `ambient.js` draws the original animated light field; it stops when off screen, hidden or reduced motion is enabled. Previous landscape media and unused styles were removed from deployed assets; previous versions remain in source history.

`i18n.js` contains 106 translation keys for Turkish, Uzbek (Latin) and English. `studio.js` updates visible text, accessible labels, metadata, email subjects, number/date formats and dynamic messages. The initial language follows a supported `?lang=` parameter, then the saved preference, then a supported browser language. Explicit choices persist locally and in the URL. Shared links preserve the selected language. Residence and location fields are omitted in every language. Statistics timestamps use UTC; regional donation labels describe support options only. Build output versions scripts and styles by content hash to avoid stale cached translations.

Run `node build-worker.mjs` after changes to the HTML template and `node verify-locales.mjs` to check translation parity, UI keys and interpolation placeholders. Translation content never uses innerHTML. No live-stream status, schedule, audience size or other game titles are fabricated. Fixed navigation accounts for header height; the footer includes motion and sharing controls.

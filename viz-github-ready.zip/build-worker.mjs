import fs from 'node:fs';import path from 'node:path';import {spawnSync} from 'node:child_process';
const root=process.cwd(),dist=path.resolve(root,'dist');
if(path.dirname(dist)!==root||path.basename(dist)!=='dist'||fs.lstatSync(dist,{throwIfNoEntry:false})?.isSymbolicLink())throw Error('Unsafe build directory');
const result=spawnSync(process.execPath,['build-studio.mjs'],{stdio:'inherit'});if(result.status!==0)process.exit(result.status||1);
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png'};
const assets={};for(const entry of fs.readdirSync('public',{withFileTypes:true})){if(!entry.isFile())throw Error('Only flat public assets are supported');const buffer=fs.readFileSync(path.join('public',entry.name));assets['/'+entry.name]={type:types[path.extname(entry.name)]||'application/octet-stream',body:buffer.toString('base64')};}
const manifest=JSON.parse(fs.readFileSync('.openai/hosting.json','utf8'));if(manifest.static)throw Error('Remove static before Worker deployment');
fs.mkdirSync(path.join(dist,'server'),{recursive:true});fs.mkdirSync(path.join(dist,'.openai'),{recursive:true});
fs.writeFileSync(path.join(dist,'server/index.js'),fs.readFileSync('worker/index.js','utf8').replace('/*__ASSETS__*/ {}',JSON.stringify(assets)));
fs.writeFileSync(path.join(dist,'.openai/hosting.json'),JSON.stringify(manifest,null,2)+'\n');
for(const name of Object.keys(assets)){const old=path.join(dist,name.slice(1));if(fs.lstatSync(old,{throwIfNoEntry:false})?.isFile())fs.unlinkSync(old);}
console.log(`Built Worker with ${Object.keys(assets).length} embedded assets and /api/stats.`);

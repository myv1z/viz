import http from 'node:http';import fs from 'node:fs';
const {default:worker}=await import('data:text/javascript;base64,'+fs.readFileSync('dist/server/index.js').toString('base64'));
http.createServer(async(req,res)=>{try{const request=new Request('http://127.0.0.1:4173'+req.url,{method:req.method});const result=await worker.fetch(request,{});res.writeHead(result.status,Object.fromEntries(result.headers));res.end(Buffer.from(await result.arrayBuffer()));}catch{res.writeHead(500).end('Preview failed');}}).listen(4173,'127.0.0.1',()=>console.log('Local: http://127.0.0.1:4173'));

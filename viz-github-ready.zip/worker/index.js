const ASSETS = /*__ASSETS__*/ {};
const STEAM_ID = '76561199473295357';
const json = (body,status=200,extra={}) => new Response(JSON.stringify(body),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...extra}});

export async function premierStats(env={},fetcher=fetch){
 const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),8000);
 try{
  const headers={Accept:'application/json'};
  if(env.LEETIFY_API_KEY)headers.Authorization=`Bearer ${env.LEETIFY_API_KEY}`;
  const response=await fetcher(`https://api-public.cs-prod.leetify.com/v3/profile?steam64_id=${STEAM_ID}`,{headers,signal:controller.signal,cache:'no-store'});
  if(response.status===429){const retry=Math.min(900,Math.max(60,Number(response.headers.get('Retry-After'))||120));return json({error:'rate_limited'},429,{'Retry-After':String(retry)});}
  if([403,404].includes(response.status))return json({error:'profile_unavailable',clear:true},503);
  if(!response.ok)return json({error:'upstream_unavailable'},502);
  const profile=await response.json();
  if(String(profile.steam64_id)!==STEAM_ID||profile.privacy_mode!=='public')return json({error:'profile_unavailable',clear:true},503);
  const rating=profile.ranks?.premier;
  if(rating!==null&&rating!==undefined&&(typeof rating!=='number'||!Number.isFinite(rating)||rating<0))return json({error:'invalid_upstream_data'},502);
  const lastTrackedMatch=(Array.isArray(profile.recent_matches)?profile.recent_matches:[]).map(m=>m.finished_at).filter(date=>typeof date==='string'&&Number.isFinite(Date.parse(date))).sort((a,b)=>Date.parse(b)-Date.parse(a))[0]||null;
  const checkedAt=new Date().toISOString();
  return json({updatedAt:checkedAt,checkedAt,lastTrackedMatch,premier:{rating:rating??null},faceit:{elo:null,level:null,kd:null,winrate:null,headshots:null},sources:{premier:{provider:'Leetify',state:rating==null?'unranked':'ok'},faceit:{state:'not_configured'}}});
 }catch{return json({error:'upstream_unavailable'},502);}finally{clearTimeout(timeout);}
}

export default {
 async fetch(request,env){
  const url=new URL(request.url);
  if(url.pathname==='/api/stats'){
   if(request.method!=='GET')return json({error:'method_not_allowed'},405,{Allow:'GET'});
   return premierStats(env);
  }
  if(!['GET','HEAD'].includes(request.method))return new Response('Method not allowed',{status:405,headers:{Allow:'GET, HEAD'}});
  const path=url.pathname==='/'?'/index.html':url.pathname;
  if(!Object.hasOwn(ASSETS,path))return new Response('Not found',{status:404});
  const asset=ASSETS[path];const binary=Uint8Array.from(atob(asset.body),character=>character.charCodeAt(0));
  return new Response(request.method==='HEAD'?null:binary,{headers:{'Content-Type':asset.type,'X-Content-Type-Options':'nosniff','Cache-Control':path==='/index.html'?'no-cache':url.searchParams.has('v')?'public, max-age=31536000, immutable':'no-cache'}});
 }
};
